# XORO
Image synthesis from text embeddings using Deep Learning on Tensorflow
